<h1>Paiement annulé</h1>
<p>
Le paiement a été annulé. En espérant que vous changerez d'avis, nous vous adressons nos salutations les plus sincères.
</p>
<?php
  // mysql_query("UPDATE commandes SET etat='annulé' WHERE id_commande='1234'");
?>