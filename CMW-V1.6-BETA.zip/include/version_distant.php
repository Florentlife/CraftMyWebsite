<?php
$versioncmsrelease = file_get_contents('http://craftmywebsite.fr/release/version.txt');
?>