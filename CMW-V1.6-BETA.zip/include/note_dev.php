<?php
$notedevdistant = file_get_contents('http://craftmywebsite.fr/release/note.txt');
?>